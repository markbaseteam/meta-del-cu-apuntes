- Se hace más competitivo el que se encadena en la producción
- En las fundiciones no se da ese caso
- Se compra concentrado en el mercado
- no se tiene proveedor único en el mercado, pero son competitivos

- fundiciones poco competitivas tienen mucho costo, estas tenían un nombre, integradas
- las otras fundiciones tienen menor dotación
- pagan menos que una empresa minera