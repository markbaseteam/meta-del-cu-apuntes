- [[Estructura básica del negocio de una fundición de Cobre]]
- cuáles son las [[Etapas de control de una reacción heterogénea]]?Las etapas de control de una reacción heterogénea son:

- [[Concentrado-hacia-la-fundición]]
- [[Clases-y-conceptos-de-Meta-del-Cu-para-el-C1-de-30_06]]