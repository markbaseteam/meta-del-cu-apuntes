Datos:
- La escoria tiene un 12 % de Magnetita Fe3O4 
- La escoria tiene un 87 % de Fayalita 2FeO SiO2
- Se supone que hay 1kg de Escoria
- Se saca [[El porcentaje de Fe en la Escoria para resolver sistema de ecuaciones]]
$$
\begin{equation}
Comp^{Hierro}_1\% \times \frac{PM_{Fe}}{PM_{CompHierro}} + Comp^{Hierro}_2\% \times \frac{PM_{Fe}}{PM_{CompHierro_2}}
\end{equation}$$
- Luego de sacar este porcentaje, se despeja la ley de Hierro en la Escoria
- Con esto se despeja la cantidad de Masa de La Mata y de la Escoria
- Sabiendo que la mata tiene un % de [[Calcosina y de Pirrotita, se saca las toneladas de eso igual.]]
