- La tecnología actual permite no contaminar
- Industria chilena tiene que encargarse de un pasado no sustentable y a la par han estado la industria alimenticia.
- Problemática: las industrias de fundición nacionales son poco competitivas, elevados costos
- Decisión de cerrar las fundiciones, como en el caso de fundición Ventanas
- Maximizar el VAN pero optimizando a largo plazo
- Chile y Japón tenían la principal capacidad de fundición en el mundo
- La de Chile se mantuvo, y pero, ha disminuído
- Netamente es un problema de Gestión
- La tecnología es netamente básica y rudimentaria.
- Cobre contenido en el mineral es menor al 1 %
- Se requiere un proceso de concentración de los Sulfuros



