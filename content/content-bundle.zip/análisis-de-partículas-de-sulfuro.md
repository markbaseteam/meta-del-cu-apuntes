- el O2 sigue difundiendo al interior de la capa
- La presión del gas se hace mayor en el interior de la partícula
- luego sufre descomposiciones
- puede explotar la partículas de tanta presión de O2 gas
- T es de 1300 grados
- expansión volumétrica del gas es enorme y genera grandes presiones
- modelos para predecir la cantidad de polvo
- costra de óxidos
- Q rad de las paredes
- Q conv velocidad de los gases
- T furnace es la t del horno
- T ignición es cuando la partícula tiene un calentamiento acelerado
- luego la partícula se calienta hasta una Tmax
- luego se enfría

[[desestabilizar-el-proceso-de-fusión]]
- todos estos fenómenos de combustión si la dosificación es buena funcionan bien
	- premisas: el concentrado se calienta y entra en ignición
- depende del tamaño de partícula y combustión de nube [[modelar-la-combustión]]