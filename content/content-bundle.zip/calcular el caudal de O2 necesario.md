- Se calcula la masa de Oxígeno relacionando el gas SO2 y el azufre eliminado
$mO_2 = mSO_2 - mS^{eliminado}$
- Luego, [[se multiplica por la eficiencia que es 98 %, en reaccionar]]
- Luego, el requerimiento de Nitrógeno es $$m_{N_2}=m_{O_2}\times \frac{\%N_2}{\%O_2}$$
- Por último, se calcula el volumen de gases en Nm3 para el Oxígeno:
$$PV=nRT = \frac{m_{O2}}{PM_{O2}} \times 0.082 \frac{atmL}{molK} \times 273 K \times \frac{10^6 g}{1 ton} \times \frac{1 m^3}{1000L}$$
- Se divide por 1 atm que es la presión atmosférica estándar
- Luego, se debe de dividir el resultado final por las toneladas de concentrado que ingresaron, que fueron 100 toneladas
- El resultado final da en Nm3/ton