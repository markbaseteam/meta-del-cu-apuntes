- La masa del Azufre se calcula con la siguiente fórmula:
- Esto es válido únicamente para los sulfuros de Cobre en la fundición

$$Masa^{Azufre} = Masa^{Concentrado} - Masa^{Cu} - Masa^{Fe} - Masa^{Ganga}$$