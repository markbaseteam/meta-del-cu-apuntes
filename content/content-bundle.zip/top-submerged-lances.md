- abreviatura de TSL
- deja de fundir y luego se separa por gravedad, lo que hace el horno es sangrar a un segundo horno de gravedad y hace la separación de fases
- lo que se hace en el mismo sedimentador o SETTLER, en el horno flash

- lanza quema combustible o inyecta oxígeno [[lanza-tiene]]
	- o inyecta gas natural, en la conversión en las [[Reacciones-de-niquel]]