- Se elimina la escoria nuevamente que es el FeO/Fe2O3/Fe3O4 
- Se elimina el Hierro
- Se elimina el fundente en la escoria CaO-SiO2
- Queda solamente el Cu2S aislado
- Necesita Oxígeno
- Sale un gas peligroso de SO2
- La ley de la primera conversión es del 73 al 79 % de Cobre
- Es importante bajar el punto de fusión de la magnetita agregando el fundente

#### Escorificación
- Lo que ocurre, es que la pirrotita reacciona con el oxígeno formando la siguiente reacción:
$$\ce{FeS + 1.5O2 -> FeO + SO2}$$
- Luego, ocurre que el FeO reacciona con el fundente, SiO2 para bajar el punto de fusión del siguiente óxido de hierro formado, que es la fayalita: 
$$\ce{FeO + SiO2 -> 2FeO*SiO2}$$