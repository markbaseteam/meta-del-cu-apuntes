### ¿Qué diagramas se utilizan para la pirometalurgia del Cobre?

