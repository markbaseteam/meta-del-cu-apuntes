- ![[Pasted image 20230327150912.png]]
- La contribución de Fe3O4 y FeO es la más negativa, en el gráfico
- Los óxidos que más fácilmente se van a formar
- Sigue la hematita y el SO2
- Comprueba de que el O2 reacciona primero con el Fe y S [[Oxidación Selectiva del Azufre]]
- Control de aproximamiento de las tasas de oxígeno y de concentrado
- Luego se controla contenido de cobre en esa fase
- ![[Pasted image 20230327151423.png]]
- Energía liberada por la formación y en referencia con el CO2(g)
- ![[Pasted image 20230327151656.png]]
#### Qué llama la atención de este diagrama?
- CO2 no tiene un poder calorífico tan grande, por mol
![[Pasted image 20230327151836.png]]
- Cambia la escala, y la energía liberada por mol es diferente a lo que pasa en operaciones reales
- Se opera en gramos, toneladas, no en unidades de moles, en las plantas
- El CO2 tiene un "salto" por el cambio de fase
- ![[Pasted image 20230327152532.png]]
- ![[Pasted image 20230327152811.png]]
- Actividad de S2 es 0.1 ya que sale del sistema
- Actividad de Calcopirita unitaria
- 100 g tengo 63 % de cobre, cuánto Cu2S?
- Tenemos 79 % de Cu2S
- FeS 21 %
- % Fe = 0.21 PMFe/PMFeS
- 13 % de Fe
- y 16 % de S, desde el dato de 79 % de Cu2S y con PM de S
- Va a favorecer las descomposiciones piríticas
- Azufre que sale del proceso, se llama Azufre lábil
- Las [[Reacciones de Pirita-Covelina-Calcopirita-Bornita]]
- Si ajustamos el contenido del Cobre a un cierto nivel, el % del Cu2S, va a llegar a 100 %
- Porqué en los diagramas de liberación de calor en kJ hay actividad de algunas especies como 0.1? Justifica desde el punto de vista si entra al sistema o si sale del sistemaLa actividad de algunas especies en los diagramas de liberación de calor en kJ se expresa como 0.1 porque se refiere a la concentración de la especie en el sistema. La actividad es una medida de la fracción molar de una especie en solución, y se utiliza para tener en cuenta las interacciones entre las moléculas en solución.

En el contexto de un diagrama de liberación de calor, la actividad puede indicar si una especie entra o sale del sistema. Si la actividad es mayor que 1, significa que hay más moléculas entrando al sistema que saliendo, lo que indica una reacción exotérmica (liberación de calor). Si la actividad es menor que 1, significa que hay más moléculas saliendo del sistema que entrando, lo que indica una reacción endotérmica (absorción de calor).

Por lo tanto, la actividad de algunas especies en los diagramas de liberación de calor puede ser importante para entender el comportamiento termodinámico del sistema y cómo se relaciona con la liberación o absorción de calor.

- Es raro porque debería significar que el S2 sale como reacción exotérmica

![[Pasted image 20230327154519.png]]
- La bornita es la que más energía libera Cu5FeS4
- Luego le sigue la calcopirita y la pirita
- La pirita es la más exotérmica?
- [[Reacción de control del proceso de fusión]]