- Se obtiene con la fórmula siguiente:

$$\begin{equation}
Masa_{Cobre} = Masa_{Especie} \times \frac{At_{Cu}^{Especie}\times PM_{Cobre}}{  PM_{Especie}}
\end{equation}$$

Donde:

$Masa_{Cobre}$: masa de cobre.

$Masa_{Especie}$: masa de la especie.

$PM_{Cobre}$: peso molecular del cobre.

$At_{Cu}^{Especie}$: átomos de cobre en la especie.

$PM_{Especie}$: peso molecular de la especie. 

