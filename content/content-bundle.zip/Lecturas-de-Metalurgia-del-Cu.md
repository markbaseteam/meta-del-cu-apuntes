- Son 8 lecturas de Metalurgia del Cobre, leeer todo de allí y aprendérselo, ya que está toda la materia de todo el curso, dice el ayudante.

[[Práctica 03_04 Meta_del_Cu]]

## Resumen de las Lecturas de Metalurgia del Cobre
### Lectura 2: Negocio de la Fundición de Cobre
1. Precio de Compra y venta del Concentrado
	- El precio de Compra y venta del concentrado viene dado por una serie de términos o acuerdos entre el comprador y el vendedor
	- La fundición de Cobre es un negocio que como cualquier otra empresa, factura por medio de la marginación entre los ingresos percibidos y los costos
	- (+, eleva precio del concentrado, está sujeto a la deducción metalúrgica)El primer término es que el precio del concentrado aumenta su valor si es que contiene elementos de interés como el Cu, Ag y Au
	- (-, son penalidades, baja precio concentrado)El segundo término es que el precio del concentrado, las fundiciones pueden aplicar penalizaciones si es que el concentrado contiene una cantidad mayor a la norma de elementos nocivos, tipo el As, Bi, Pb, Sb
	- (-, son costos de la fundición) El TC/RC, se basa en los cargos hechos desde que se trata el concentrado proveniente de la planta concentradora, hasta que se produce el Cobre tipo A
		- El TC, es el Treatment Charge, se basa en que es el costo de tratamiento de la fundición desde que se obtiene el concentrado de cobre hasta que se obtiene un cobre anódico
			- Se mide en dólares por tonelada seca de cobre, en usd/Dmt
		- El RC, es el Refining Charge, se basa en que es el costo de tratamiento de la fundición, desde que se obtiene el cobre anódico hasta el Cobre tipo A
			- El cobre tipo A es de uso industrial
			- Se mide en centavos de dólar por libra de cobre refinado
			- 1 ton son alrededor de 2200 lb
			- 1 ton tiene una ley o base de cálculo de 0.28t si su ley es de 0.28 % 
	- Se asume una pérdida metalúrgica, el cual es el término de la [[Deducción metalúrgica]]
		- "Me vendes 100 t de concentrado pero te pagaré solamente el 97.5 % de Cu, el 95% de Au y el 95% de Ag, porque mi proceso no puede recuperar más"
			- Te pago solamente el 97.5% del cobre ya que el 2.5% lo pierdo en mi proceso
			- Penalización, por elementos nocivos en el concentrado, tipo As, El Zn entorpece el proceso, se volatiliza, y va por los ductos de los gases, causando problemas
			- El Bismuto igual causa problemas
			- El mercurio
			- El Zinc
			- El Hidrógeno
		- El TC/RC es el costo que tiene la fundición para producir cobre anódico al 99.5 % en dólar por DMT, mientras que el RC es el costo para producir cobre refinado al 99.99 %, cobre tipo A y de uso industrial
### Tema de las penalizaciones
- Es otro tipo de ingreso para las fundiciones de Cobre, por el costo asociado a tratar elementos que son peligrosos, nocivos, ya sea para el medio ambiente tanto como para las personas, como para un posible daño a la tecnología presente en las fundiciones. 

### (+/-)Price Participation
- Hay un precio de venta acordado por el comprador y el vendedor, del valor del Cobre
	- "Cada vez que haya un signo (+), esto significa un ingreso para la mina"
	- Eso, eleva el precio del concentrado y la fundición paga más por el concentrado
	- (+)Que sea positivo el PP, quiere decir que el precio del cobre está en un valor mayor al precio de venta acordado
	- Pero, esto es como injusto, y la mina debe de hacer participar más de sus ganancias a la fundición
	- (-)Mientras que el PP negativo, quiere decir que la fundición debe de participar en las menores ganancias que va a obtener la mina 

### Test 2 de Meta del Cu
#### Tipos de Convertidores
#### Convertidor Hoboken
- El convertidor Hoboken reduce la emisión del polvo y de los gases
- El aire se inyecta por tuberías del convertidor
- Se elimina el Fe y el S en una etapa de manera simultáneas
#### Convertidor TBRC
- El convertidor TBRC, el aire se inyecta por una lanza por la parte superior del convertidor
- Tiene una forma cilíndrica, es rotatorio y gira sobre un eje inclinado. 

[[Estudio-de-Lecturas-de-Meta-del-Cu-con-Claude]]

