![[control 1 - 2012.pdf]]

- Puede ser que por un contrato de venta a largo plazo el precio del cobre promedie en un valor por debajo del precio actual del Cobre. 
- Si se mantienen o aumenta el costo de Producción del metal
- El tipo de cambio del USDCLP aumenta, entre menor sea el valor del dólar, mayores son las ganancias para la empresa ?
- La demanda de Cobre disminuye para esa empresa minera, a pesar de que el precio de Cobre haya aumentado

![[control 2 - 2010.pdf]]

![[control 2 - 2013.pdf]]

![[Control 2 + examen 2012.pdf]]

![[control 3 - 2013.pdf]]