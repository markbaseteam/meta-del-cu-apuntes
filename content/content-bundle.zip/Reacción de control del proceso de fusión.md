![[Pasted image 20230327154706.png]]
- Es la reacción que controla la composición de cobre en la mata
- No la cantidad de cobre en la mata!!
- [[Presión-de-oxígeno-de-la-reacción-de-control-fundición]]
- [[Estructura básica del negocio de una fundición de Cobre]]