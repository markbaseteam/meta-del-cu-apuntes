1. Realice un balance de masa y determinar el coficiente de O2 para usar en una fundición de Cu para obtener ley al 63%

| Compuesto | CuFeS2 | Cu5FeS4 | Cu2S   | CuS   | FeS2 | Al2O3  | SiO2 |     
| --------- | ------ | ------- | ------ | ----- | ---- | ------ | ---- | 
| %         | 15     | 22      | 10     | 4     | 41   | 4      | 4    |    
| PM        | 183.5  | 501.4   | 159.16 | 95.54 | 120  | 101.96 | 60   |

- Primero hay que hacer el [[Balance-de-Especies-Practica2-MetaCu]]
- [[Consideraciones-en-el-desarrollo-de-ejercicios-Práctica2-MetaCu]]
- Realice un balance de masa, determinar la cantidad de Cu, Fe, de Al, de O y de S para las siguientes especies: CuFeS2, 15%, Cu5FeS4, 22 %, Cu2S, 10 %, CuS, 4 %, FeS2, 41 %, Al2O3, 4 %, SiO2, 4 %, y sus pesos moleculares respectivos son: 183.5, 501.4, 159.16, 95.54, 120, 101.96, 60, respectivamente y en ese orden
- [[Escoria-del-Ejercicio2-de-Meta_Cu]]

[[Lo-que-entró-en-el-test-02-deMetaCu]]

[[Práctica-MetaCu-para-el-día-27_04]]

[[Práctica-4-de-Meta-del-Cu]]