![[Problema 1, met de cu.pdf]]

![[Problema 2, met de cu.pdf]]

![[Problema 4 y 6 - listado escorias.pdf]]

![[Reduccion de escorias oxidos.pdf]]

![[Clase_01.pptx]]
![[Balance C1 2010.xlsx]]
![[Ejemplo clase 01-04-19.xlsx]]
![[Ejemplo clase 21-03-19.xlsx]]
![[Ejercicio Listado 1.xlsx]]
![[Libro1.xlsx]]

- Requerimiento de oxígeno y fundente para una fundición, global
- Luego para cada una de las etapas
- Están amarrados entre sí
- Depende de la ley objetivo
- ¿Qué pasa cuando aumenta la pirita en el balance de masa de la fundición? 
- El contenido de cobre disminuye
- Para producir la misma cantidad de algo, debería de tener más consumo de..
- 1) Procesar más
- 2) Generar más escoria
- ¿Qué pasa si aumenta la calcopirita?
- Todo esto, se debe de reajustar en la planta.
- Cada ton de cobre, produce 2 ton de escoria, 1 es a 2
- Cuánto ácido sulfúrico se produce?
- Producción de ácido sulfúrico en función de un porcentaje de captura
- Cómo se declara ese porcentaje
- Hay abatimiento, se produce sulfato de calcio, yeso?

![[Práctica 1 Meta Del Cu.pdf]]


#### Repaso de Ejercicio de Práctica de la Semana Pasada
- [x] Pasarle al Navarrete Material de Meta del Cu

[[Desarrollo-de-Ejercicio-Práctica1-Meta-del-Cu]]

Dime las masas molares de las siguientes especies, redondea a un decimal:

CuFeS2, calcopirita
Cu5FeS4, bornita
Cu2S, calcosina
CuS, covelina
FeS2, pirita
SiO2, sílice

CuFeS2, calcopirita: 183.5 g/mol
Cu5FeS4, bornita: 663.1 g/mol
Cu2S, calcosina: 159.2 g/mol
CuS, covelina: 95.6 g/mol
FeS2, pirita: 119.98 g/mol
SiO2, sílice: 60.08 g/mol

[[Lecturas-de-Metalurgia-del-Cu]]