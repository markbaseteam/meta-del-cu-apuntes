- la [[reacción-de-Cu2S_Cu]]
- si tenemos un 80 % de Cu en Cu2S
- el complemento es el 20 % 
- diagrama de fases en la segunda conversión
	- se elimina azufre
	- de 20% llega a una eliminación total de S
	- la reacción molecular es violenta y es electroquímica, de iones
- GRÁFICAS DE SLAG BROWN son las presiones parciales antes del soplado de cobre
- como sube se tiene un nivel de oxidación más potente o posibilidad de oxidar
- si se elimina el FeS entonces mayor posibilidad de hacer reaccionar al Cu2S 

[[Reacción-de-Cu2S_Cu2O]]
[[no-se-recupera-Cu-o-Fe-en-la-escoria]]
- el negocio de la fundición también es imporante la recuperación