- fundiciones en cadena de valor están adelante de la extracción minera
	- Esto quiere decir de que es el último eslabón de la minería, entonces, las plantas hidro también lo serían
	- o bien es el primer eslabón de la cadena, del sector indusrtial o de la cadena de manufactura.
		- Las sub industrias, pueden considerarse como: alambres, alambrones, transmisión energética, intercambiadores de calor, electrónica, microelectrónica
- Más valor por unidad de masa conforme la cadena de valor se va incrementando
	- Por ejemplo, para el caso de los semiconductores, que estos son pequeños y son extremadamente caros
- costo de la mano de obra de operadores de la fundición

[[fundiciones-custom]]