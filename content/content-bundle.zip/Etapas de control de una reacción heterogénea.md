- $A+B=C+D$
- La reacción de la especie A hacia B
- [[Conceptos C2 de Cinética]]
- [[Transferencia de masa]]
- La descripción es Termodinámica para los procesos Pirometalúrgicos
- La velocidad de reacción quiere decir que casi es instantánea, son extremadamente rápidas
- Control, capacidad ingenieril para alimentar a fusión y/o conversión
- Cómo se desactiva una animación grabada en una presentación de powerpoint?
- [[Ecuación de la energía libre de Gibbs]]


