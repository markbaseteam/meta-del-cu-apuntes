- Se saca usando el 63 % de Ley de Cobre en el Eje o Mata
- Se usa la Siguiente fórmula: 
$$\begin{equation}
Cu_2S_{\%} = Ley\ de\ Cu_{Eje} \times \frac{PM_{Cu_2S}}{PM_{Cu}}
\end{equation}$$
