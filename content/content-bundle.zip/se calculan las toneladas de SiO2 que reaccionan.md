-  Esto se hace por medio de la Fayalita, con la siguiente fórmula:

$m_{SiO_2}^{reacciona} = m^{Fayalita} \times \frac{PM_{SO_2}}{PM_{Fayalita}}$
- Criterio de las toneladas de SiO2 obtenidas
- Si son Menores a la cantidad disponible en la Calcina, entonces no se necesita agregar fundente
- Y hay una cantidad en exceso de toneladas de SiO2