#### l. Fundamentos
- Negocio, química y cinética
- Principios fundamentales del proceso y descripción de los circuitos de Cu, Fe y S
- Fundamentos de la fisicoquímica
- Estructura básica para análisis del negocio

#### ll. Descripción tecnológica para cada subproceso
- Fusión y conversión
- Pirorefinación de Cu blíster
- Escorias en la pirometalurgia del cobre
- Limpieza de escorias

#### lll. Tópicos Complementarios
- Producción de ácido sulfúrico, tecnología y mercado
- Elementos menores, valorización de residuos, producción de Cu secundario
- Normativa ambiental, emisiones de SO2 y As
- Nuevas propuestas para el procesamiento de concentrados, procesos Hidros y H2 verde

[[Nuevas tecnologías e industria de la fundición]]

[[Proceso de flotación para la fundición]]

¿Porqué se necesita de bajar la temperatura de fusión de los óxidos de Hierro en la escoria usando fundente como SiO2 y CaO en la fundición y en la primera conversión donde se sopla el Hierro y en los dos se obtiene una escoria?

La razón principal por la que se necesita bajar la temperatura de fusión de los óxidos de hierro en la escoria utilizando fundentes como SiO2 y CaO es para facilitar el proceso de separación del hierro y la escoria. 

Durante el proceso de fundición, el mineral de hierro se mezcla con coque y se somete a altas temperaturas en un horno para producir hierro líquido y escoria. La escoria es una mezcla de óxidos no metálicos que se forman durante el proceso de fusión y que flotan sobre el hierro líquido debido a su menor densidad.

El uso de fundentes como SiO2 y CaO ayuda a reducir la temperatura de fusión de los óxidos presentes en la escoria, lo que facilita su separación del hierro líquido. Además, estos fundentes también ayudan a eliminar impurezas no deseadas en la escoria, lo que mejora la calidad del hierro producido.

En resumen, bajar la temperatura de fusión de los óxidos en la escoria mediante el uso de fundentes es esencial para facilitar el proceso de separación del hierro y la escoria durante la fundición y mejorar la calidad del producto final. 



