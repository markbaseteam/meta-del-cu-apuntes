- El precio valúa los elementos de valor, si tiene Au y Ag, se suma el valor del precio del concentrado
- [[Se elimina las penalidades de los elementos que son nocivos]]
- Se elimina la suposición de que las tecnologías y equipos no son perfectos para recuperar 100 %, 97.5 % es un porcentaje
- TC/RC se elimina, no es un valor que fije cada cual, TC/RC es el valor fijado por el mercado, se fija en un bar en Lisboa
- Deducción metalúrgica del cobre es de 3.35 %
	- Deducción metalúrgica será como las pérdidas de los metales valiosos? SI
- Deducción metalúrgica del Au es del 2.50 %
- Deducción metalúrgica de la Ag es del 10.00 %
- Si recupera sobre la deducción metalúrgica, 100 % utilidad, puede comprar 95 % y le sacó 97 %, utilidad neta
- [[Treatment Charge & Refining Charge]]
- [[Price-Participation-fundición-minero]]
- El flete es tema importante para el minero que para el fundidor
- Fundiciones son cerca del puerto
- Las minas están donde están
- 1ro negociar el precios
- 2do costos para procesar concentrados
- 3ro recuperación metalúrgica
- Excelencia operacional
- [[Cálculo de ejemplo-de-una-fundición]]
- Negocio de las fundiciones, compran sobre 1.5 Mt de Concentrado de cobre
- Con una ley del 26 % de cobre
- Con 390,000 ton de Cu

### Ejemplo de la deducción metalúrgica
- Es la pérdida que se tiene de los elementos valiosos como el Cu, Ag y Au presentes en el concentrado. -
- La deducción metalúrgica está fijada de manera personal o bien de manera internacional ????
	- Deducción metalúrgica del cobre es de 3.35 %, quiere decir que se asume que se recupera un piso de 96.65 % de Cobre
	- Deducción metalúrgica del Oro es de un 2.5 %, quiere decir que se asume que se recupera un piso de 97.5 % de Oro
	- En la plata se recupera un 90 % ya que la deducción metalúrgica es de un 10 %. 
- Si recupero encima de la deducción metalúrgica, eso es un 100 % de utilidad!!!, para la fundición, directo al bolsillo de la misma
#### Para el caso de la Ley de Concentrado
- La ley de un concentrado de cobre convencional es del 26% al 30 % de Cobre
	- Imagina que viene alguna empresa minera y quiere venderlo a 23 %, entonces, la nueva deducción metalúrgica ganó un punto, 4.45 %, quiere decir que se comprarán 100 t de concentrado pero con un valor de 95.65 % 
		- Esto es la deducción metalúrgica en base a la unidad, que juzga solamente por la ley de cobre
			- Le resta un punto a la ley de Cobre,p ej, si vende un concentrado a 27 %, el 26 % tendrá valor
- La deducción metalúrgica de la Unidad, se utiliza para los porcentajes de leyes de cobre MENORES al 30 %
	- La DM del porcentaje, se usa para las leyes de Cobre mayores a 30 %
- La mayoría ocupa MIXTO, solo que se ve ese último incremento

- Deducción metalúrgica es la cantidad que puedo recuperar de los elementos, que se resta del 100%, ese resultado es tu deducción metalúrgica, ya que los procesos no son 100 % eficientes. 