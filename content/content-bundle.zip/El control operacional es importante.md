- Independiente de una energía libre de Gibbs muy negativa y muy favorable, el control es importante, ya que puede ser que se "vaya de las manos" la oxidación de las especies
- Generando tanto calor que el horno se calienta
- Generando demasiados gases, la capacidad de tratamiento de gases colapsa
- No es problema fisicoquímico
#### Concepto de Potencial de Oxígeno
- [[Controlar la temperatura]]