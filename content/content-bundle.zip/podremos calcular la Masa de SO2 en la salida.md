- Se calcula a partir de la [[fundente, debemos de sacar los gases]]
- Se calcula a partir del Azufre eliminado 
$$m_{SO_2} = m_{S,{eliminada}} \times \frac{P_{SO_2}}{P_{MS}}$$