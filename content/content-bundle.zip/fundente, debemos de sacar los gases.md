- Primero se debe de sacar la masa de Azufre eliminada
$mS_{eliminada} = mS_{concentrado} - mS_{mata}$
- La mS concentrado es la masa calculada al principio, la masa que tiene el Azufre en el concentrado
- Al igual, existe la masa del Cu y del Fe en el concentrado
- El concentrado es de 100 toneladas
- [[La masa de Azufre en la Mata]]
- Con esta masa de azufre eliminada [[podremos calcular la Masa de SO2 en la salida]]
- Luego, [[calcular el caudal de O2 necesario]]