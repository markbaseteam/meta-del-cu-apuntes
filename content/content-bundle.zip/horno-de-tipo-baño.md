- problemas del reactor teniente, es una boca abierta
- pierde energía al enfriar gases
- [[Coeficiente-de-oxígeno-agregar-N2]] si aumento el coeficiente de O2 entonces baja el volumen de gas 
- menor volumen, o sea que se consume menor energía, trabajar a mayor enriquecimiento es un mayor objetivo
- las fundiciones de cobre generan energía
- mayor consumo es por energía eléctrica
	- tipo, para mover los gases de SO2 a planta de ácido con sopladores
- mov. de gases, ollas o de equipos
- 20% de combustibles fósiles, cuando se para los equipos se ponen los quemadores de petróleo
- noranda tiene una captura y canalización de gases cerrada

**Reactor con toberas o aire**
- A diferencia del [[tipos-de-reactores-de-fusión]] como el horno flash

**Cómo funciona un horno tipo baño**
- Se inyecta el concentrado mediante un artilugio o una lanza
- [[lanza-tiene]]
	- tobera
	- por tobera a presión o por la lanza
	- la partícula se descompone y genera azufre
	- adicional necesitamos oxígeno
	- no se produce una llama, es una oxidación en baño!! y genero mucha energía
- es un sistema sumamente agitado
- se forma una burbuja y se forma una costra alrededor de la tobera
- burbuja son de 25 cm de SO2 y de O2
	- mecanismo de la reacción es distinto al de fusión flash
- tenemos un baño de Cu2S y de FeS
- la temperatura es del orden de los 1300°C
- CuFeS2 se va a descomponer
- en todas las reacciones como primera etapa sucede que se forma [[azufre-pirítico]]
- inyecto concentrado en el baño, en cambio en el horno flash se produce una combustión
- la partícula llega al baño
- el producto de este reactor requiere un horno adicional
	- flash teniente y noranda van a conversión directa
- En el TSL, [[top-submerged-lances]] va a un horno decantador o sedimentador, a diferencia de que se hace de inmediato en el horno flash en el settler
- horno [[Vanuykov]]
- horno [[Bottom-blowing]]
- [[SKS]]