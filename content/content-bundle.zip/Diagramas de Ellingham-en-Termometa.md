- Se tiene que hay un equilibrio de dos especies
- Por ejemplo, se pide analizar la posibilidad del equilibrio en el diagrama de Ellingham:
- K+O2=K2O
- 2Co+O2=2CoO
- [[Equilibrio de K2O y CoO]]


