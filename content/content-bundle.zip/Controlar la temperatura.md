Si es que la t° baja:
- Traer aire caliente
- Oxidación de la pirita (genera más escoria)
- Un quemador (cuando los hornos están fríos)
-  