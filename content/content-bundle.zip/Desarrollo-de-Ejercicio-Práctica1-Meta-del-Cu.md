#### Conceptos importantes del Ejercicio
- Estamos ante la entrada de un concentrado que es una calcina que viene de la tostación para poder fundir el Cobre
- Entra [[aire enriquecido]] al 58 % 
- Normalmente el concentrado de cobre que es la calcina que entra consiste en Calcopirita, Bornita, Covelina y Calcosina
- El nitrógeno no reacciona, es un gas inerte que sale de la fusión
- Se debe de obtener un [[concentrado Fayalítico 2FeO SiO2]]
- Hay que evitar obtener un [[concentrado de magnetita]]
- El concentrado de la Fusión es el Cu2S-FeS [[Flowsheet de una fundición]]

#### Desarrollo del Ejercicio
- Se tiene que la calcina tiene un cierto porcentaje para cada especie
- Hay que suponer una base de cálculo de 100 toneladas de concentrado
- Se tiene que sacar el [[cobre contenido en cada uno de los minerales]]
- Lo mismo se debe de hacer para la cantidad de Hierro en cada uno de los minerales
- Sacar por diferencia la [[Masa del Azufre]]
- La ley de Cobre en el Eje o Mata es del 63 %
- La ley de Magnetita en la escoria es del 12 %
- Hay que sacar [[el porcentaje de Cu2S en la Salida]]
- El resto es el Porcentaje que corresponde a la Pirrotita, que es el 21 %
- Luego, quiero saber el [[% de Hierro presente en la Escoria]]
- Luego, [[se calculan las toneladas de SiO2 que reaccionan]]
- Luego de tener claro lo del [[fundente, debemos de sacar los gases]]