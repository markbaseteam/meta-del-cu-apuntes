- La oxidación es selectiva
- El oxígeno va a preferir en todo momento reaccionar con el Fe y el S en vez del Cu
- Herramienta de la termo para ver este análisis?
- A 700° C otienes CO o tienes CO2 para el sistema C+O2=CO2 y 2C+O2=2CO
- El sistema de SO2 y SO3, a 1000 ° C

- Entran los gases O2 N2(g)
- Entran los fundentes SiO2 y CaO 
- Sale el gas N2 