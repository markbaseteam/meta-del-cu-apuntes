![[Pasted image 20230320140927.png]]
- Si se observa en el gráfico, se cruza la línea de 4K+O2=2K2O a una temperatura de aproximadamente 970 °C en el diagrama, entonces:
- A una temperatura menor a 970°C, el óxido del 2K2O es más estable que el óxido de CoO
- Por ende, se dice que el K potasio va a reducir al CoO, transformándolo a Cobalto puro Co.
- Para una temperatura superior, la cosa se invierte.