- Se calcula como sigue:
- Escribe la fórmula en fomato latex: m FeS x (PMS)/(PMFeS) + mCu2S x (PMS)/(PMCu2S)
$$m_{FeS} \times \frac{P_{MS}}{P_{MFeS}} + m_{Cu2S} \times \frac{P_{MS}}{P_{MCu2S}}$$