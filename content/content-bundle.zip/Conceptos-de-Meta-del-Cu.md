#### Qué hace una fundición de Cobre?
- Trata un concentrado para luego transformarlo a un ánodo de cobre 
- El ánodo de cobre es un metal al 99.5 % de Pureza.
- Ese ánodo no puede tener mucho contenido de As y S, eso se hace en la [[Tostación desarsinificante]]
- Este último es un cobre Puro, No refinado!
- Se agregan fundentes para bajar la temperatura de fusión de los óxidos de Hierro.

[[Clase 01- Meta del Cu]]



#### ¿Cómo se logra la obtención del Cu de alta pureza?
- Una fundición de Cu, trata el concentrado de cobre 25-30 % mezcla de sulfuros de cobre y hierro
- Gracias a procesos de oxidación, se oxida el azufre y el hierro, son reacciones espontáneas 



