- El sistema de Ecuaciones consiste en:

$$\begin{equation}
Masa^{Cobre} = TonMata \times LeyCu^{mata} + TonEscoria \times LeyCu^{escoria}
\end{equation} $$

$$\text{Masa}^\text{Hierro} = \text{TonMata} \times \text{LeyFe}^\text{mata} + \text{TonEscoria} \times \text{LeyFe}^\text{escoria}$$

