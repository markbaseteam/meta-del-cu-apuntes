- TC, "Cargo de tratamiento", aplicado por la fundición está relacionado con el costo de procesamiento del concentrado hasta cobre anódico. El valor se expresa en dólares por tonelada de concentrado seco (US$/tonelada seca).
	- Tonelada seca se dice DMT, "Dry metric Ton"
- Subía el precio del cobre y se valoriza la acción de fundir
- Subía el TC/RC
- Ahora no tienen ninguna "lógica"
- Depende de la capacidad instalada

- RC, "Cargo de refinación": aplicado por la fundición está relacionado con el costo que incurrirá la refinería electrolítica para transformar el cobre anódico en cobre cátodo grado A. El valor se expresa en centavos por libra de cobre refinable (¢/lb).
- Cobre catódico o cobre de tipo A para venta
### Nota importante
- El TC/RC es un costo que imparte la fundición o descuento que hace por comprar el concentrado